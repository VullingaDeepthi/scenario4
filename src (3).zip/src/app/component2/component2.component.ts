// src/app/component2/component2.component.ts
import { Component, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-component2',
  templateUrl: './component2.component.html',
  styleUrls: ['./component2.component.css']
})
export class Component2Component {
  userInput: string = '';

  @Output() textEntered = new EventEmitter<string>();

  sendText() {
    this.textEntered.emit(this.userInput);
  }
}
